from django.urls import path
from . import views

urlpatterns = [
    # ============ AUTH URLS ============
    path('', views.index, name='index'),  # Login page
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    
    # ============ PAGE URLS ============
    path('success/', views.success, name='success'),  # Home page
    path('calculator/', views.calculator, name='calculator'),
    path('premium/', views.premium, name='premium'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('reports/', views.reports, name='reports'),
    
    # ============ PAYMENT URLS ============
    path('payment/', views.payment_page, name='payment_page'),
    path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
    path('payment/success/', views.payment_success, name='payment_success'),
    path('payment/cancel/', views.payment_cancel, name='payment_cancel'),
    path('payment/free-trial/', views.activate_free_trial, name='activate_free_trial'),
    path('stripe-webhook/', views.stripe_webhook, name='stripe_webhook'),

     path('reports/generate-pdf/', views.generate_pdf_report, name='generate_pdf'),
    path('reports/download-csv/', views.download_csv, name='download_csv'),

    # frontend/urls.py
# urlpatterns = [
#     path('', views.payment_page, name='payment'),
#     path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
#     path('success/', views.payment_success, name='payment_success'),
#     path('cancel/', views.payment_cancel, name='payment_cancel'),
# ]
]