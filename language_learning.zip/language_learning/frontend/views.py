# from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login, logout
# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.decorators import login_required
# from django.contrib import messages
# import stripe
# from django.conf import settings
# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# from .models import UserProfile, PaymentHistory
# from django.utils import timezone
# from datetime import timedelta

# # Initialize Stripe
# stripe.api_key = settings.STRIPE_SECRET_KEY

# # ============ AUTH VIEWS ============

# def index(request):
#     """Login page"""
#     if request.user.is_authenticated:
#         return redirect('success')
#     return render(request, 'index.html')

# def login_view(request):
#     """Handle login"""
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         user = authenticate(request, username=username, password=password)
        
#         if user is not None:
#             login(request, user)
#             messages.success(request, f'Welcome back, {username}!')
#             return redirect('success')
#         else:
#             messages.error(request, 'Invalid username or password')
    
#     return redirect('index')

# def logout_view(request):
#     """Handle logout"""
#     logout(request)
#     messages.info(request, 'You have been logged out.')
#     return redirect('index')

# def register(request):
#     """Handle registration"""
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             username = form.cleaned_data.get('username')
#             password = form.cleaned_data.get('password1')
#             user = authenticate(username=username, password=password)
#             login(request, user)
#             messages.success(request, f'Account created successfully! Welcome, {username}!')
#             return redirect('success')
#         else:
#             for field, errors in form.errors.items():
#                 for error in errors:
#                     messages.error(request, f"{field}: {error}")
#     else:
#         form = UserCreationForm()
    
#     return render(request, 'index.html', {'form': form})

# # ============ PAGE VIEWS ============

# @login_required
# def success(request):
#     """Home page after login"""
#     return render(request, 'success.html')

# @login_required
# def calculator(request):
#     """Carbon calculator page"""
#     return render(request, 'calculator.html')

# @login_required
# def premium(request):
#     """Premium features page"""
#     return render(request, 'premium.html')

# @login_required
# def dashboard(request):
#     """User dashboard"""
#     return render(request, 'dashboard.html')

# @login_required
# def reports(request):
#     """Reports page"""
#     return render(request, 'reports.html')

# # ============ PAYMENT VIEWS ============

# @login_required
# def payment_page(request):
#     """Show payment page"""
#     return render(request, 'payment_page.html')

# @login_required
# def create_checkout_session(request):
#     """Create Stripe checkout session"""
#     try:
#         # Get or create user profile
#         profile, created = UserProfile.objects.get_or_create(user=request.user)
        
#         # Create checkout session
#         checkout_session = stripe.checkout.Session.create(
#             payment_method_types=['card'],
#             line_items=[{
#                 'price_data': {
#                     'currency': 'usd',
#                     'product_data': {
#                         'name': 'CarbonSense Premium',
#                         'description': 'Monthly Subscription',
#                     },
#                     'unit_amount': 499,  # $4.99 in cents
#                 },
#                 'quantity': 1,
#             }],
#             mode='subscription',
#             success_url=request.build_absolute_uri('/payment/success/') + '?session_id={CHECKOUT_SESSION_ID}',
#             cancel_url=request.build_absolute_uri('/payment/cancel/'),
#             metadata={
#                 'user_id': request.user.id,
#             }
#         )
        
#         return redirect(checkout_session.url)
        
#     except Exception as e:
#         messages.error(request, f"Error: {str(e)}")
#         return redirect('payment_page')

# @login_required
# def payment_success(request):
#     """Handle successful payment"""
#     session_id = request.GET.get('session_id')
    
#     if session_id:
#         try:
#             # Retrieve session from Stripe
#             session = stripe.checkout.Session.retrieve(session_id)
            
#             # Update user profile
#             profile, created = UserProfile.objects.get_or_create(user=request.user)
#             profile.is_premium = True
#             profile.premium_start_date = timezone.now()
#             profile.premium_end_date = timezone.now() + timedelta(days=30)  # 1 month
#             profile.stripe_customer_id = session.customer
#             profile.save()
            
#             # Save payment record
#             PaymentHistory.objects.create(
#                 user=request.user,
#                 amount=4.99,
#                 stripe_payment_intent=session.payment_intent,
#                 status='completed'
#             )
            
#             messages.success(request, "🎉 Payment successful! Premium activated!")
#             return redirect('premium')  # REDIRECT TO PREMIUM PAGE
            
#         except Exception as e:
#             messages.error(request, f"Error processing payment: {str(e)}")
#             return redirect('payment_page')
#     else:
#         messages.error(request, "No session ID found.")
#         return redirect('payment_page')

# @login_required
# def payment_cancel(request):
#     """Handle cancelled payment"""
#     messages.info(request, "Payment was cancelled. You can try again anytime.")
#     return redirect('premium')  # REDIRECT TO PREMIUM PAGE

# @login_required
# def activate_free_trial(request):
#     """Activate free trial"""
#     profile, created = UserProfile.objects.get_or_create(user=request.user)
#     profile.is_premium = True
#     profile.premium_start_date = timezone.now()
#     profile.premium_end_date = timezone.now() + timedelta(days=7)  # 7 days trial
#     profile.save()
    
#     messages.success(request, "🎉 7-day free trial activated!")
#     return redirect('dashboard')

# # TEST VERSION - Skip Stripe (Uncomment if needed)
# """
# @login_required
# def create_checkout_session(request):
#     # TEST VERSION - Skip Stripe and simulate payment
#     profile, created = UserProfile.objects.get_or_create(user=request.user)
#     profile.is_premium = True
#     profile.premium_start_date = timezone.now()
#     profile.premium_end_date = timezone.now() + timedelta(days=30)
#     profile.save()
    
#     # Save test payment record
#     PaymentHistory.objects.create(
#         user=request.user,
#         amount=4.99,
#         stripe_payment_intent='test_payment_001',
#         status='completed'
#     )
    
#     messages.success(request, "🎉 Premium activated! (Test Mode)")
#     return redirect('premium')
# """

# # Webhook (optional for now)
# @csrf_exempt
# def stripe_webhook(request):
#     """Handle Stripe webhooks"""
#     return JsonResponse({'status': 'success'})

# # ============ EXTRA VIEWS (Optional) ============

# @login_required
# def profile_view(request):
#     """View user profile"""
#     try:
#         profile = UserProfile.objects.get(user=request.user)
#     except UserProfile.DoesNotExist:
#         profile = UserProfile.objects.create(user=request.user)
    
#     context = {
#         'user': request.user,
#         'profile': profile
#     }
#     return render(request, 'profile.html', context)

# @login_required
# def instructions(request):
#     """Show demo instructions"""
#     return render(request, 'instructions.html')

# # frontend/views.py
# def payment_success(request):
#     # Mark user as premium
#     if request.user.is_authenticated:
#         request.user.is_premium = True  # Add this field to your User model
#         request.user.save()
    
#     return render(request, 'payment_success.html')

# def payment_cancel(request):
#     return render(request, 'payment_cancel.html')


# frontend/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import stripe
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import UserProfile, PaymentHistory
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth import get_user_model
from .forms import CustomUserCreationForm, CustomAuthenticationForm  # Import forms

# Get the custom user model
User = get_user_model()

# Initialize Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

# ============ AUTH VIEWS ============

def index(request):
    """Login page"""
    if request.user.is_authenticated:
        return redirect('success')
    
    login_form = CustomAuthenticationForm()
    register_form = CustomUserCreationForm()
    
    context = {
        'login_form': login_form,
        'register_form': register_form,
    }
    return render(request, 'index.html', context)

def login_view(request):
    """Handle login"""
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {username}!')
                return redirect('success')
            else:
                messages.error(request, 'Invalid username or password')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = CustomAuthenticationForm()
    
    return render(request, 'index.html', {'login_form': form})

def logout_view(request):
    """Handle logout"""
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('index')

def register(request):
    """Handle registration with CustomUser"""
    if request.method == 'POST':
        # Use CustomUserCreationForm
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Auto-login after registration
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, f'Account created successfully! Welcome, {username}!')
                return redirect('success')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
            
            # Return to index with form errors
            login_form = CustomAuthenticationForm()
            return render(request, 'index.html', {
                'register_form': form,
                'login_form': login_form
            })
    
    # GET request - show empty form
    form = CustomUserCreationForm()
    login_form = CustomAuthenticationForm()
    return render(request, 'index.html', {
        'register_form': form,
        'login_form': login_form
    })

# ============ PAGE VIEWS ============

@login_required
def success(request):
    """Home page after login"""
    return render(request, 'success.html')

@login_required
def calculator(request):
    """Carbon calculator page"""
    return render(request, 'calculator.html')

@login_required
def premium(request):
    """Premium features page"""
    return render(request, 'premium.html')

@login_required
def dashboard(request):
    """User dashboard"""
    return render(request, 'dashboard.html')

@login_required
def reports(request):
    """Reports page"""
    return render(request, 'reports.html')

# ============ PAYMENT VIEWS ============

@login_required
def payment_page(request):
    """Show payment page"""
    return render(request, 'payment_page.html')

@login_required
def create_checkout_session(request):
    """Create Stripe checkout session"""
    try:
        # Get or create user profile
        profile, created = UserProfile.objects.get_or_create(user=request.user)
        
        # Create checkout session
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': 'CarbonSense Premium',
                        'description': 'Monthly Subscription',
                    },
                    'unit_amount': 499,  # $4.99 in cents
                },
                'quantity': 1,
            }],
            mode='subscription',
            success_url=request.build_absolute_uri('/payment/success/') + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.build_absolute_uri('/payment/cancel/'),
            metadata={
                'user_id': request.user.id,
            }
        )
        
        return redirect(checkout_session.url)
        
    except Exception as e:
        messages.error(request, f"Error: {str(e)}")
        return redirect('payment_page')

@login_required
def payment_success(request):
    """Handle successful payment"""
    session_id = request.GET.get('session_id')
    
    if session_id:
        try:
            # Retrieve session from Stripe
            session = stripe.checkout.Session.retrieve(session_id)
            
            # Update user profile
            profile, created = UserProfile.objects.get_or_create(user=request.user)
            profile.is_premium = True
            profile.premium_start_date = timezone.now()
            profile.premium_end_date = timezone.now() + timedelta(days=30)  # 1 month
            profile.stripe_customer_id = session.customer
            profile.save()
            
            # Save payment record
            PaymentHistory.objects.create(
                user=request.user,
                amount=4.99,
                stripe_payment_intent=session.payment_intent,
                status='completed'
            )
            
            messages.success(request, "🎉 Payment successful! Premium activated!")
            return redirect('premium')
            
        except Exception as e:
            messages.error(request, f"Error processing payment: {str(e)}")
            return redirect('payment_page')
    else:
        messages.error(request, "No session ID found.")
        return redirect('payment_page')

@login_required
def payment_cancel(request):
    """Handle cancelled payment"""
    messages.info(request, "Payment was cancelled. You can try again anytime.")
    return redirect('premium')

@login_required
def activate_free_trial(request):
    """Activate free trial"""
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    profile.is_premium = True
    profile.premium_start_date = timezone.now()
    profile.premium_end_date = timezone.now() + timedelta(days=7)  # 7 days trial
    profile.save()
    
    messages.success(request, "🎉 7-day free trial activated!")
    return redirect('dashboard')

# Webhook (optional)
@csrf_exempt
def stripe_webhook(request):
    """Handle Stripe webhooks"""
    return JsonResponse({'status': 'success'})

# ============ EXTRA VIEWS ============

@login_required
def profile_view(request):
    """View user profile"""
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)
    
    context = {
        'user': request.user,
        'profile': profile
    }
    return render(request, 'profile.html', context)

@login_required
def instructions(request):
    """Show demo instructions"""
    return render(request, 'instructions.html')


# frontend/views.py
def payment_success(request):
    # Mark user as premium
    if request.user.is_authenticated:
        request.user.is_premium = True  # Add this field to your User model
        request.user.save()
    
    return render(request, 'payment_success.html')

def payment_cancel(request):
    return render(request, 'payment_cancel.html')




# frontend/views.py - reports function update karein
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
import json
from django.utils import timezone

@login_required
def reports(request):
    """Generate carbon footprint reports (Premium feature only)"""
    
    # Check if user is premium
    if not request.user.userprofile.is_premium:
        messages.warning(request, "⚠️ This is a premium feature. Upgrade to access detailed reports.")
        return redirect('premium')
    
    # Premium user - show reports
    return render(request, 'reports.html')

@login_required
def generate_pdf_report(request):
    """Generate PDF report (Premium feature)"""
    
    # Check if user is premium
    if not request.user.userprofile.is_premium:
        return HttpResponse("Premium feature only", status=403)
    
    # Create PDF
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    
    # Add content to PDF
    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, 750, "CarbonSense - Carbon Footprint Report")
    
    p.setFont("Helvetica", 12)
    p.drawString(100, 720, f"User: {request.user.username}")
    p.drawString(100, 700, f"Date: {timezone.now().strftime('%Y-%m-%d')}")
    p.drawString(100, 680, f"Status: {'Premium User' if request.user.userprofile.is_premium else 'Free User'}")
    
    # Add some sample data
    p.drawString(100, 650, "Monthly Carbon Footprint Analysis")
    p.drawString(100, 630, "Transportation: 120 kg CO2")
    p.drawString(100, 610, "Electricity: 85 kg CO2")
    p.drawString(100, 590, "Food: 65 kg CO2")
    p.drawString(100, 570, "Waste: 30 kg CO2")
    p.drawString(100, 550, "Total: 300 kg CO2")
    
    p.drawString(100, 500, "Recommendations:")
    p.drawString(100, 480, "1. Use public transport 3 times/week")
    p.drawString(100, 460, "2. Switch to LED bulbs")
    p.drawString(100, 440, "3. Reduce meat consumption")
    
    p.showPage()
    p.save()
    
    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf', 
                       headers={'Content-Disposition': 'attachment; filename="carbon_report.pdf"'})

@login_required
def download_csv(request):
    """Download data as CSV (Premium feature)"""
    
    if not request.user.userprofile.is_premium:
        return HttpResponse("Premium feature only", status=403)
    
    import csv
    from django.http import HttpResponse
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="carbon_data.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Date', 'Category', 'Carbon (kg)', 'Cost ($)'])
    writer.writerow(['2024-01', 'Transport', '120', '45'])
    writer.writerow(['2024-01', 'Electricity', '85', '60'])
    writer.writerow(['2024-01', 'Food', '65', '80'])
    writer.writerow(['2024-01', 'Waste', '30', '15'])
    writer.writerow(['Total', '', '300', '200'])
    
    return response

